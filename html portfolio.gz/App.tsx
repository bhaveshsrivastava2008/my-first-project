import React, { useEffect, useMemo, useRef, useState } from 'react';
import { ArrowUpRight, Mail, Github, Linkedin, Phone, MapPin, GraduationCap, Code2, PenTool, MessageSquare, ChevronDown, ArrowDown, Layers, Target, BookOpen, Gamepad2, Sparkles, CircleAlert, NotebookPen } from 'lucide-react';

type Skill = { name: string; level: number; tag: string; group: string; note: string };

const ALL_SKILLS: Skill[] = [
  { name: 'Python', level: 58, tag: 'Beginner', group: 'Programming', note: 'can build basic projects, learning as I go' },
  { name: 'HTML5', level: 72, tag: 'Fundamentals', group: 'Programming', note: 'comfortable with structure, building with it regularly' },
  { name: 'CSS3', level: 68, tag: 'Fundamentals', group: 'Programming', note: 'layout works, practising alignment' },
  { name: 'JavaScript', level: 42, tag: 'Learning', group: 'Programming', note: 'currently learning, focusing on async' },
  { name: 'Frontend fundamentals', level: 66, tag: 'Fundamentals', group: 'Web & Tools', note: 'getting better, one small page at a time' },
  { name: 'Responsive layout', level: 62, tag: 'Fundamentals', group: 'Web & Tools', note: 'mostly works, improving mobile layouts' },
  { name: 'Browser localStorage', level: 60, tag: 'Fundamentals', group: 'Web & Tools', note: 'can save + load simple things' },
  { name: 'VS Code · Git · GitHub', level: 54, tag: 'Beginner', group: 'Web & Tools', note: 'commits work, learning merge workflows' },
  { name: 'AI tools & prompt writing', level: 70, tag: 'Fundamentals', group: 'AI & Creative', note: 'useful, but I check the output myself' },
  { name: 'Canva', level: 74, tag: 'Fundamentals', group: 'AI & Creative', note: 'easiest one on this list, honestly' },
  { name: 'Carousel design', level: 68, tag: 'Fundamentals', group: 'AI & Creative', note: 'can make a clean set' },
  { name: 'Content planning', level: 66, tag: 'Fundamentals', group: 'AI & Creative', note: 'ideas are fine, focusing on finishing' },
  { name: 'Technology communication', level: 72, tag: 'Fundamentals', group: 'Other', note: 'explaining simply is something I like' },
  { name: 'Task organization', level: 76, tag: 'Fundamentals', group: 'Other', note: 'lists everywhere. it helps.' },
  { name: 'Self-learning', level: 80, tag: 'Fundamentals', group: 'Other', note: 'this one is doing most of the work' },
  { name: 'Project documentation', level: 64, tag: 'Fundamentals', group: 'Other', note: 'writing it down after I build' },
];

const TOP6 = [
  { name: 'Self-learning', level: 80, note: 'figuring it out, consistently' },
  { name: 'Task organization', level: 76, note: 'lists + small steps' },
  { name: 'Canva', level: 74, note: 'my comfort zone' },
  { name: 'HTML5', level: 72, note: 'solid basics' },
  { name: 'Technology communication', level: 72, note: 'plain words first' },
  { name: 'AI tools & prompt writing', level: 70, note: 'helpful, not magic' },
];

const GROUPS = [
  { label: 'Programming', avg: 60, detail: 'Python · HTML5 · CSS3 · JavaScript', color: '#2563EB' },
  { label: 'Web & Tools', avg: 61, detail: 'Frontend · Responsive · localStorage · Git', color: '#1D4ED8' },
  { label: 'AI & Creative', avg: 70, detail: 'AI tools · Canva · Carousels · Planning', color: '#3B82F6' },
  { label: 'Other', avg: 73, detail: 'Communication · Organisation · Learning', color: '#64748B' },
];

const PROJECTS = [
  { no: '01', title: 'FocusFlow', sub: 'Productivity Web Project', status: 'working', statusNote: 'in progress', desc: 'A small productivity page I made to keep my own tasks in order. It is simple. It helps me see what I have to do today without getting lost in the layout.', tags: ['Task systems', 'Interface layout', 'Local persistence'], stack: 'HTML · CSS · JS · localStorage', points: ['Task systems that stay simple to use', 'Interface layout planned for everyday use', 'Local persistence in the browser'], learned: 'What I learned: I learned to make the simple version first, then stop.' },
  { no: '02', title: 'ZERO/BUILD', sub: 'Beginner-Friendly Technology Education Initiative', status: 'working', statusNote: 'slowly growing', desc: 'This is me trying to explain tech the way I wish someone had explained it to me. Short, plain-language lessons, mostly as carousels. Made for people starting from zero — like me, not that long ago.', tags: ['AI tools', 'Canva', 'Carousel design'], stack: 'AI tools · Canva · Carousel design', points: ['Beginner-first explanations', 'Carousel lessons made to be shared', 'Content planned for steady learning'], learned: 'What I learned: writing simply takes practice. My first drafts had words I did not need.' },
  { no: '03', title: 'ORYNTHVEIL', sub: 'Game Development Concept', status: 'idea stage', statusNote: 'mostly notes + sketches', desc: 'A game idea I keep coming back to. Right now it is more of a notebook than a game — the world, the choices, what the player would actually care about. I am learning Godot alongside it, so progress is slow.', tags: ['Godot', 'Game design', 'Player decisions'], stack: 'Godot · Game design · Player decisions', points: ['Concept and game design direction', 'Player decisions at the centre', 'Built while learning Godot'], learned: 'What I learned: movement takes patience. I stepped away, then came back fresh.' },
  { no: '04', title: 'Developer Resume & Portfolio Development', sub: 'GitHub / LinkedIn / Documentation', status: 'working', statusNote: 'needs work', desc: 'This page. And my GitHub, LinkedIn, and notes around them. I keep updating things as I learn more, and I keep finding old descriptions that no longer sound like me.', tags: ['GitHub', 'LinkedIn', 'Documentation'], stack: 'GitHub · LinkedIn · Documentation', points: ['Portfolio built from real work', 'Documentation kept up to date', 'Profiles aligned with projects'], learned: 'What I learned: I rewrote it to sound more like how I actually talk.' },
];

const INTERESTS = [
  { icon: Layers, title: 'Full-stack development', text: 'Learning how the front and back of an app fit together.' },
  { icon: Sparkles, title: 'AI / ML', text: 'Using AI tools, and slowly learning how they work underneath.' },
  { icon: Gamepad2, title: 'Game development', text: 'Ideas, decisions, and play — explored in Godot, one step at a time.' },
  { icon: Code2, title: 'Software projects', text: 'Small, useful software made step by step.' },
  { icon: BookOpen, title: 'Technology education', text: 'Explaining tech so beginners can start without feeling lost.' },
  { icon: PenTool, title: 'UI / UX design', text: 'Interfaces that feel calm and clear. Learning what that means.' },
];

const MARQUEE = ['Python', 'HTML5', 'CSS3', 'JavaScript', 'Godot', 'AI Tools', 'Canva', 'GitHub', 'Responsive Layout', 'Content Planning'];
const LOG = [
  { day: 'Mon', text: 'Worked on async in JavaScript. Making steady progress.' },
  { day: 'Wed', text: 'Fixed a layout bug in FocusFlow that had been there for days. It was one line.' },
  { day: 'Fri', text: 'Worked on Godot movement. Tuning how the player moves.' },
  { day: 'Sun', text: 'Cleaned up my GitHub a bit and wrote notes for this portfolio. It feels more like me now.' },
];
function useInView<T extends HTMLElement>() {
  const ref = useRef<T | null>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    if (!ref.current) return;
    const obs = new IntersectionObserver(([e]) => { if (e.isIntersecting) { setInView(true); obs.disconnect(); } }, { threshold: 0.12 });
    obs.observe(ref.current);
    return () => obs.disconnect();
  }, []);
  return { ref, inView };
}
function Reveal({ children, delay = 0, className = '' }: { children: React.ReactNode; delay?: number; className?: string }) {
  const { ref, inView } = useInView<HTMLDivElement>();
  return <div ref={ref} className={`reveal ${inView ? 'is-in' : ''} ${className}`} style={{ transitionDelay: `${delay}ms` }}>{children}</div>;
}
function Scribble() {
  return <svg viewBox="0 0 220 12" className="mt-2 h-[10px] w-[180px] max-w-full" aria-hidden="true"><path d="M3 8 C 30 3, 55 11, 82 6 S 140 3, 168 7 S 200 9, 217 5" fill="none" stroke="#2563EB" strokeWidth="2.5" strokeLinecap="round" /></svg>;
}
function SectionHead({ no, eyebrow, title, sub }: { no: string; eyebrow: string; title: string; sub: string }) {
  return (
    <div className="max-w-3xl">
      <div className="flex items-center gap-3"><span className="mono text-[12px] font-semibold tracking-[0.16em] text-[#2563EB]">{no} — {eyebrow}</span><span className="h-px flex-1 bg-[#191919]/25" aria-hidden="true" /></div>
      <h2 className="serif mt-4 text-[clamp(1.85rem,5vw,2.9rem)] font-semibold leading-[1.05] tracking-[-0.015em] text-[#191919]">{title}</h2>
      <Scribble />
      <p className="mt-3 text-[16px] leading-relaxed text-[#4B4A45]">{sub}</p>
    </div>
  );
}
function Radar() {
  const { ref, inView } = useInView<HTMLDivElement>();
  const cx = 150, cy = 150;
  const pts = GROUPS.map((g, i) => { const angle = (Math.PI * 2 * i) / 4 - Math.PI / 2; const r = 28 + (g.avg / 100) * 96; return `${(cx + r * Math.cos(angle)).toFixed(1)},${(cy + r * Math.sin(angle)).toFixed(1)}`; }).join(' ');
  const labels = [
    { x: 150, y: 18, a: 'middle', t: 'Programming · 60%' },
    { x: 288, y: 152, a: 'start', t: 'Web & Tools · 61%' },
    { x: 150, y: 288, a: 'middle', t: 'Other · 73%' },
    { x: 12, y: 152, a: 'start', t: 'AI & Creative · 70%' },
  ];
  return (
    <div ref={ref} className="relative">
      <svg viewBox="0 0 300 300" className="mx-auto w-full max-w-[380px]" role="img" aria-label="Radar chart showing average level for four skill groups">
        {[96, 72, 48, 24].map(r => <polygon key={r} points={Array.from({ length: 4 }, (_, i) => { const a = (Math.PI * 2 * i) / 4 - Math.PI / 2; return `${cx + r * Math.cos(a)},${cy + r * Math.sin(a)}`; }).join(' ')} fill="none" stroke="#D8D2C2" strokeWidth="1" />)}
        <line x1="150" y1="54" x2="150" y2="246" stroke="#D8D2C2" /><line x1="54" y1="150" x2="246" y2="150" stroke="#D8D2C2" />
        <polygon points={pts} fill="rgba(37,99,235,0.10)" stroke="#2563EB" strokeWidth="2" className="radar-poly" style={{ opacity: inView ? 1 : 0 }} />
        {GROUPS.map((g, i) => { const a = (Math.PI * 2 * i) / 4 - Math.PI / 2; const r = 28 + (g.avg / 100) * 96; return <circle key={g.label} cx={cx + r * Math.cos(a)} cy={cy + r * Math.sin(a)} r="5" fill="#2563EB" stroke="white" strokeWidth="2" style={{ opacity: inView ? 1 : 0, transition: `opacity .5s ${0.3 + i * 0.12}s` }} />; })}
        {labels.map(l => <text key={l.t} x={l.x} y={l.y} textAnchor={l.a} className="mono" fontSize="10" fontWeight="600" fill="#334155">{l.t}</text>)}
      </svg>
      <div className="mt-1 flex flex-wrap justify-center gap-2">{GROUPS.map(g => <span key={g.label} className="inline-flex items-center gap-1.5 rounded-full border border-[#191919]/25 bg-white px-2.5 py-1 text-[11px] font-semibold text-[#334155]"><span className="h-2 w-2 rounded-full" style={{ background: g.color }} />{g.label} {g.avg}%</span>)}</div>
    </div>
  );
}
function Donut({ name, level, index, inView, note }: { name: string; level: number; index: number; inView: boolean; note: string }) {
  const R = 34, C = 2 * Math.PI * R;
  const [shown, setShown] = useState(0);
  useEffect(() => {
    if (!inView) return;
    let raf = 0; const start = performance.now(); const dur = 950 + index * 100;
    const tick = (t: number) => { const p = Math.min(1, (t - start) / dur); setShown(Math.round(level * (1 - Math.pow(1 - p, 3)))); if (p < 1) raf = requestAnimationFrame(tick); };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [inView, level, index]);
  return (
    <div className="flex flex-col items-center text-center">
      <div className="relative h-[92px] w-[92px]">
        <svg viewBox="0 0 84 84" className="h-full w-full -rotate-90"><circle cx="42" cy="42" r={R} fill="none" stroke="#E5E0D3" strokeWidth="8" /><circle cx="42" cy="42" r={R} fill="none" stroke="#2563EB" strokeWidth="8" strokeLinecap="round" strokeDasharray={C} strokeDashoffset={inView ? C - (C * level) / 100 : C} className="donut-arc" /></svg>
        <div className="absolute inset-0 flex items-center justify-center"><span className="serif text-[20px] font-bold tracking-tight text-[#191919]">{shown}<span className="text-[13px]">%</span></span></div>
      </div>
      <p className="mt-2.5 text-[13px] font-bold leading-tight text-[#191919]">{name}</p>
      <p className="hand mt-1 text-[12.5px] leading-snug text-[#2563EB]">{note}</p>
    </div>
  );
}

export default function App() {
  const [progress, setProgress] = useState(0);
  const [filter, setFilter] = useState('All');
  const [openProject, setOpenProject] = useState(0);
  const [active, setActive] = useState('home');
  const donutWrap = useInView<HTMLDivElement>();
  const filters = ['All', 'Programming', 'Web & Tools', 'AI & Creative', 'Other'];
  useEffect(() => {
    const onScroll = () => {
      const h = document.documentElement; const max = h.scrollHeight - h.clientHeight;
      setProgress(max > 0 ? Math.min(100, (h.scrollTop / max) * 100) : 0);
      const ids = ['home', 'about', 'log', 'skills', 'projects', 'interests', 'contact'];
      for (const id of ids) { const el = document.getElementById(id); if (el && el.getBoundingClientRect().top <= 140) setActive(id); }
    };
    onScroll(); window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);
  const filtered = useMemo(() => filter === 'All' ? ALL_SKILLS : ALL_SKILLS.filter(s => s.group === filter), [filter]);
  const avg = Math.round(ALL_SKILLS.reduce((a, s) => a + s.level, 0) / ALL_SKILLS.length);
  const scrollTo = (id: string) => document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });

  return (
    <div data-safe-area-inset-root style={{ boxSizing: 'border-box', paddingTop: 'var(--safe-area-inset-top)' }} className="min-h-screen overflow-x-clip bg-[var(--surface)] text-[var(--text)]">
      <div className="fixed left-0 right-0 top-0 z-[60] h-[3px] bg-[#D8D2C2]" aria-hidden="true"><div className="h-full bg-[#2563EB] transition-[width] duration-150" style={{ width: `${progress}%` }} /></div>

      <header data-safe-area-sticky-top style={{ top: 'var(--safe-area-inset-top)' }} className="sticky z-50 border-b-2 border-[#191919] bg-[#FFFEFA]">
        <div className="mx-auto flex h-[64px] max-w-6xl items-center justify-between gap-3 px-4 sm:px-6">
          <button onClick={() => scrollTo('home')} className="flex items-center gap-2.5 text-left" aria-label="Back to top">
            <span className="flex h-9 w-9 rotate-[-2deg] items-center justify-center border-2 border-[#191919] bg-[#191919] text-[13px] font-extrabold text-white">BS</span>
            <span className="leading-none"><span className="serif block text-[15px] font-bold tracking-tight">Bhavesh Srivastava</span><span className="mono mt-0.5 block text-[10px] uppercase tracking-[0.14em] text-[#7A786E]">my notes · 2026</span></span>
          </button>
          <nav className="hidden items-center gap-6 text-[13.5px] font-semibold text-[#4B4A45] md:flex" aria-label="Sections">
            {([['about', 'About'], ['log', 'Log'], ['skills', 'Skills'], ['projects', 'Projects'], ['interests', 'Interests']] as const).map(([id, label]) => (
              <button key={id} onClick={() => scrollTo(id)} className={`nav-link ${active === id ? 'active text-[#191919]' : 'hover:text-[#191919]'}`}>{label}</button>
            ))}
          </nav>
          <div className="flex items-center gap-2">
            <span className="hidden items-center gap-1.5 rounded-full border border-[#191919]/25 bg-[#F7F3EA] px-3 py-1.5 text-[11px] font-bold text-[#334155] sm:flex"><span className="h-2 w-2 rounded-full bg-[#2563EB]" />Open to internships</span>
            <button onClick={() => scrollTo('contact')} className="rounded-full border-2 border-[#191919] bg-[#2563EB] px-4 py-2 text-[13px] font-bold text-white transition hover:bg-[#1E40AF] active:scale-95">Contact</button>
          </div>
        </div>
        <div className="flex gap-1.5 overflow-x-auto px-4 pb-2 md:hidden" aria-label="Mobile sections">
          {([['about', 'About'], ['log', 'Log'], ['skills', 'Skills'], ['projects', 'Projects'], ['interests', 'Interests'], ['contact', 'Contact']] as const).map(([id, label]) => (
            <button key={id} onClick={() => scrollTo(id)} className="shrink-0 rounded-full border border-[#191919]/30 bg-white px-3 py-1.5 text-[12px] font-bold text-[#334155] active:bg-[#EAF0FE]">{label}</button>
          ))}
        </div>
      </header>

      <main>
        {/* HERO */}
        <section id="home" className="relative">
          <div className="relative mx-auto max-w-6xl px-4 pb-8 pt-9 sm:px-6 sm:pt-14">
            <div className="grid items-start gap-8 lg:grid-cols-[1.45fr_.9fr]">
              <div>
                <div className="animate-rise flex flex-wrap items-center gap-2" style={{ animationDelay: '40ms' }}>
                  <span className="rounded-full border border-[#191919]/30 bg-[#FFFEFA] px-3 py-1.5 text-[12px] font-bold text-[#1E40AF]">1st-year B.Tech · Computer Science (AI)</span>
                  <span className="rounded-full border border-[#191919]/30 bg-[#FFFEFA] px-3 py-1.5 text-[12px] font-bold text-[#334155]">NIAT × Joy University · Tamil Nadu</span>
                </div>
                <div className="relative">
                  <h1 className="serif animate-rise mt-5 text-[clamp(2.6rem,8vw,5rem)] font-semibold leading-[0.98] tracking-[-0.025em] text-[#191919]" style={{ animationDelay: '100ms' }}>Hi, I’m<br /><span className="relative inline-block">Bhavesh<span className="absolute -bottom-1 left-0 h-[4px] w-full bg-[#2563EB]/70" aria-hidden="true" /></span><br /><span className="text-[#2563EB]">Srivastava.</span></h1>
                  <p className="hand absolute right-0 top-2 hidden rotate-[4deg] text-[15px] text-[#2563EB] lg:block">← yep, that’s me<br /><span className="text-[12px] text-[#4B4A45]">currently learning -&gt;</span></p>
                </div>
                <p className="animate-rise mt-6 max-w-xl text-[17px] leading-relaxed text-[#4B4A45] sm:text-[18px]" style={{ animationDelay: '180ms' }}>
                  First-year student. This is my first year, so I’m figuring things out as I go. I’m learning <strong className="text-[#191919]">JavaScript</strong> and <strong className="text-[#191919]">Godot</strong> right now — step by step.
                </p>
                <p className="animate-rise mt-3 max-w-xl text-[15px] leading-relaxed text-[#4B4A45]">I’m building. This page is the most honest version I’ve made so far.</p>
              </div>

              <div className="animate-rise tape rotate-[0.6deg] rounded-[4px] border-2 border-[#191919] bg-[#FFFEFA] p-5 shadow-[4px_5px_0_rgba(25,25,25,0.14)]" style={{ animationDelay: '220ms' }}>
                <div className="flex items-center justify-between"><p className="mono text-[11px] font-semibold uppercase tracking-[0.16em] text-[#7A786E]">At a glance</p><span className="rounded-full bg-[#EAF0FE] px-2.5 py-1 text-[11px] font-bold text-[#2563EB]">2026 — Present</span></div>
                <div className="mt-5 grid grid-cols-2 gap-3">
                  {[{ v: '4', l: 'Projects in progress' }, { v: '16', l: 'Skills being tracked' }, { v: `${avg}%`, l: 'Average skill level' }, { v: '6', l: 'Interests & directions' }].map(s => (
                    <div key={s.l} className="rounded-[4px] border border-[#191919]/20 bg-[#F7F3EA] p-3.5"><p className="serif text-[28px] font-bold leading-none tracking-tight text-[#191919]">{s.v}</p><p className="mt-1.5 text-[12px] font-semibold leading-snug text-[#4B4A45]">{s.l}</p></div>
                  ))}
                </div>
                <div className="mt-4 flex items-start gap-3 rounded-[4px] border border-dashed border-[#191919]/40 bg-[#EAF0FE] p-3.5">
                  <GraduationCap className="mt-0.5 h-5 w-5 shrink-0 text-[#2563EB]" />
                  <p className="text-[13.5px] leading-relaxed text-[#334155]"><strong>B.Tech · Computer Science, AI Specialization</strong><br />NIAT × Joy University · First Year</p>
                </div>
                <div className="mt-4 flex items-start gap-2.5 rounded-[4px] border border-[#191919]/25 bg-[#FFFEFA] p-3.5">
                  <CircleAlert className="mt-0.5 h-5 w-5 shrink-0 text-[#2563EB]" />
                  <p className="text-[13.5px] leading-relaxed text-[#334155]"><strong>Currently learning:</strong> JavaScript async — and Godot movement. Working on it step by step.</p>
                </div>
                <button onClick={() => scrollTo('about')} className="mt-4 flex w-full items-center justify-center gap-2 rounded-full border border-[#191919]/30 py-2.5 text-[13px] font-bold text-[#334155] transition hover:border-[#2563EB] hover:text-[#2563EB] active:scale-95">More about me <ArrowDown className="h-4 w-4" /></button>
              </div>
            </div>

            <div className="mt-9 grid grid-cols-2 gap-px overflow-hidden rounded-[4px] border-2 border-[#191919] bg-[#191919] sm:grid-cols-4">
              {[['01', 'FocusFlow — productivity'], ['02', 'ZERO/BUILD — education'], ['03', 'ORYNTHVEIL — game concept'], ['04', 'Portfolio — in progress']].map(([n, t]) => (
                <div key={n} className="flex items-center gap-3 bg-[#FFFEFA] px-4 py-3.5"><span className="mono text-[12px] font-bold text-[#2563EB]">{n}</span><span className="text-[12.5px] font-bold leading-tight text-[#334155]">{t}</span></div>
              ))}
            </div>
            <p className="hand mt-3 text-right text-[13px] text-[#2563EB]">↑ my first project! — still my favourite to fix</p>
          </div>

          <div className="overflow-hidden border-y-2 border-[#191919] bg-[#FFFEFA] py-3" aria-label="Skills marquee">
            <div className="marquee-track flex w-max items-center gap-8 whitespace-nowrap">{[...MARQUEE, ...MARQUEE].map((m, i) => <span key={i} className="flex items-center gap-8 text-[13px] font-bold uppercase tracking-[0.16em] text-[#334155]">{m}<span className="h-1.5 w-1.5 rounded-full bg-[#2563EB]" /></span>)}</div>
          </div>
        </section>

        {/* ABOUT */}
        <section id="about" className="mx-auto max-w-6xl px-4 py-12 sm:px-6 sm:py-16">
          <Reveal><SectionHead no="01" eyebrow="ABOUT" title="Learning the foundations, properly." sub="First-year B.Tech student at NIAT × Joy University. The work right now is foundations — and writing them down as they grow." /></Reveal>
          <div className="mt-8 grid gap-5 lg:grid-cols-[1.2fr_.8fr]">
            <Reveal>
              <div className="relative h-full rounded-[4px] border-2 border-[#191919] bg-[#FFFEFA] p-6 shadow-[3px_4px_0_rgba(25,25,25,0.10)] sm:p-8">
                <p className="hand absolute -top-3 right-4 rotate-[2deg] bg-[#F7F3EA] px-2 text-[13px] text-[#2563EB]">honest version →</p>
                <p className="text-[17px] leading-relaxed text-[#334155]">I’m a first-year B.Tech student in Computer Science (AI). I like <strong>making small software, learning AI/ML, and building projects</strong> that help people learn or get organised. I’m building slowly — one concept, one project, one documented step at a time.</p>
                <p className="mt-4 text-[15px] leading-relaxed text-[#4B4A45]">I’m building my foundations. A lot of this page is “I can do the basics, and I’m working on the rest.”</p>
                <div className="mt-6 grid gap-2.5 sm:grid-cols-2">
                  {['Python fundamentals', 'HTML', 'CSS', 'Beginner JavaScript', 'Browser localStorage', 'GitHub workflows', 'AI tools', 'Content creation'].map(x => <div key={x} className="flex items-center gap-2.5 rounded-[4px] border border-[#191919]/15 bg-[#F7F3EA] px-3.5 py-2.5 text-[13.5px] font-bold text-[#334155]"><span className="h-1.5 w-1.5 shrink-0 rounded-full bg-[#2563EB]" />{x}</div>)}
                </div>
                <p className="mt-6 rounded-[4px] border border-dashed border-[#2563EB]/60 bg-[#EAF0FE] p-4 text-[13.5px] leading-relaxed text-[#334155]"><strong className="text-[#1E40AF]">Note:</strong> The focus is on strengthening foundations — and being open about where the work is happening now.</p>
              </div>
            </Reveal>
            <Reveal delay={100}>
              <div className="flex h-full flex-col gap-4">
                <div className="rotate-[-0.4deg] rounded-[4px] border-2 border-[#191919] bg-[#191919] p-6 text-white">
                  <p className="mono text-[11px] uppercase tracking-[0.16em] text-[#94A3B8]">Education</p>
                  <h3 className="serif mt-3 text-[20px] font-semibold leading-tight">B.Tech · Computer Science<br />AI Specialization</h3>
                  <p className="mt-2 text-[14px] text-[#CBD5E1]">NIAT × Joy University</p>
                  <div className="mt-5 flex items-center justify-between border-t border-white/20 pt-4 text-[13px] font-bold"><span>First Year</span><span className="rounded-full bg-[#2563EB] px-3 py-1">2026 — Present</span></div>
                </div>
                <div className="rotate-[0.4deg] rounded-[4px] border-2 border-[#191919] bg-[#FFFEFA] p-6">
                  <p className="mono text-[11px] uppercase tracking-[0.16em] text-[#7A786E]">Right now</p>
                  <ul className="mt-3 space-y-2.5 text-[14px] font-semibold text-[#334155]">
                    <li>→ Learning JavaScript, step by step</li>
                    <li>→ Exploring Godot &amp; game ideas</li>
                    <li>→ Building FocusFlow &amp; ZERO/BUILD</li>
                  </ul>
                  <p className="hand mt-3 text-[13px] text-[#2563EB]">in progress</p>
                </div>
              </div>
            </Reveal>
          </div>

        </section>

        {/* LOG */}
        <section id="log" className="border-y-2 border-[#191919] bg-[#EFEAE0] py-12 sm:py-16">
          <div className="mx-auto max-w-6xl px-4 sm:px-6">
            <Reveal><SectionHead no="01½" eyebrow="LOG" title="What I did this week." sub="A short diary, not a highlight reel. Some weeks are just fixing one bug and writing it down." /></Reveal>
            <div className="mt-8 grid gap-4 lg:grid-cols-[1.15fr_.85fr]">
              <Reveal>
                <div className="paper-lines rounded-[4px] border-2 border-[#191919] bg-[#FFFEFA] p-6 sm:p-7">
                  <p className="mono flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.16em] text-[#7A786E]"><NotebookPen className="h-4 w-4 text-[#2563EB]" /> Notebook — this week</p>
                  <ul className="mt-4 space-y-4">
                    {LOG.map(l => <li key={l.day} className="flex gap-3"><span className="mono mt-0.5 shrink-0 rounded-full border border-[#191919]/30 bg-[#F7F3EA] px-2.5 py-1 text-[11px] font-bold">{l.day}</span><span className="text-[15px] leading-relaxed text-[#334155]">{l.text}</span></li>)}
                  </ul>
                  <p className="hand mt-5 text-[14px] text-[#2563EB]">— not a big week, but a real one.</p>
                </div>
              </Reveal>
              <Reveal delay={100}>
                <div className="flex h-full flex-col gap-4">
                  <div className="rotate-[0.5deg] rounded-[4px] border-2 border-[#191919] bg-[#FFFEFA] p-6"><p className="mono text-[11px] uppercase tracking-[0.16em] text-[#7A786E]">Currently learning</p><h3 className="serif mt-2 text-[20px] font-semibold leading-snug">JavaScript async<br />+ Godot movement</h3><p className="mt-2 text-[14px] leading-relaxed text-[#4B4A45]">I’m re-reading, re-trying, and asking for help when I need it.</p></div>
                  <div className="rotate-[-0.5deg] rounded-[4px] border border-dashed border-[#191919]/50 bg-[#FFFEFA] p-5"><p className="hand text-[15px] leading-relaxed text-[#191919]">“Currently learning →” — I write this on a lot of pages. It’s true every time.</p><p className="mt-2 text-[13px] text-[#4B4A45]">Small progress still counts. That’s the whole idea of this log.</p></div>
                </div>
              </Reveal>
            </div>
          </div>
        </section>

        {/* SKILLS */}
        <section id="skills" className="border-b-2 border-[#191919] bg-[#FFFEFA] py-12 sm:py-16">
          <div className="mx-auto max-w-6xl px-4 sm:px-6">
            <Reveal><SectionHead no="02" eyebrow="SKILLS" title="Where the work is happening now." sub="Bars show where work is happening now. Levels are my own honest guess — and they change as I learn." /></Reveal>
            <div className="mt-8 grid gap-5 lg:grid-cols-2">
              <Reveal><div className="h-full rounded-[4px] border-2 border-[#191919] bg-white p-6 sm:p-7">
                <div className="flex items-center justify-between gap-3"><div><p className="mono text-[11px] uppercase tracking-[0.16em] text-[#7A786E]">Skill groups</p><h3 className="serif mt-1 text-[19px] font-semibold">Radar · 4 groups</h3></div><span className="rounded-full bg-[#EAF0FE] px-3 py-1 text-[12px] font-bold text-[#2563EB]">Avg {avg}%</span></div>
                <div className="mt-4"><Radar /></div>
                <p className="mt-4 text-center text-[12.5px] leading-relaxed text-[#7A786E]">Group averages from the 16 skills below. “Other” leads — built on self-learning and organisation. Learning steadily in the rest.</p>
              </div></Reveal>
              <Reveal delay={80}><div className="h-full rounded-[4px] border-2 border-[#191919] bg-white p-6 sm:p-7">
                <p className="mono text-[11px] uppercase tracking-[0.16em] text-[#7A786E]">Strongest right now</p>
                <h3 className="serif mt-1 text-[19px] font-semibold">Top 6 · Donut rings</h3>
                <div ref={donutWrap.ref} className="mt-6 grid grid-cols-2 gap-x-4 gap-y-6 sm:grid-cols-3">{TOP6.map((s, i) => <Donut key={s.name} name={s.name} level={s.level} index={i} inView={donutWrap.inView} note={s.note} />)}</div>
                <div className="mt-6 flex items-center gap-2 rounded-[4px] border border-[#191919]/15 bg-[#F7F3EA] px-3.5 py-3 text-[12.5px] font-semibold text-[#4B4A45]"><Target className="h-4 w-4 shrink-0 text-[#2563EB]" />Self-learning at 80% is doing most of the work here. The rest is growing.</div>
              </div></Reveal>
            </div>
            <Reveal>
              <div className="mt-5 rounded-[4px] border-2 border-[#191919] bg-white p-5 sm:p-7">
                <div className="flex flex-wrap items-end justify-between gap-4">
                  <div><p className="mono text-[11px] uppercase tracking-[0.16em] text-[#7A786E]">All 16 skills</p><h3 className="serif mt-1 text-[19px] font-semibold">Animated levels — with honest notes</h3></div>
                  <div className="flex flex-wrap gap-1.5" role="group" aria-label="Filter skills">{filters.map(f => <button key={f} onClick={() => setFilter(f)} className={`rounded-full px-3.5 py-2 text-[12.5px] font-bold transition active:scale-95 ${filter === f ? 'border-2 border-[#191919] bg-[#191919] text-white' : 'border border-[#191919]/30 bg-white text-[#334155] hover:border-[#2563EB] hover:text-[#2563EB]'}`}>{f}</button>)}</div>
                </div>
                <div className="mt-6 grid gap-x-8 gap-y-5 md:grid-cols-2">{filtered.map((s, i) => <SkillBar key={s.name} skill={s} index={i} />)}</div>
                <p className="mt-6 text-[12.5px] font-semibold text-[#7A786E]">Showing {filtered.length} of 16 skills · {filter === 'All' ? 'All groups' : filter} · These % are my best guess, not a test score.</p>
              </div>
            </Reveal>
          </div>
        </section>

        {/* PROJECTS */}
        <section id="projects" className="mx-auto max-w-6xl px-4 py-12 sm:px-6 sm:py-16">
          <Reveal><SectionHead no="03" eyebrow="PROJECTS" title="Four projects, four directions." sub="Tap a project to see what it is and what it uses. Each one is in progress." /></Reveal>
          <div className="mt-8 space-y-3">
            {PROJECTS.map((p, i) => {
              const open = openProject === i;
              return (
                <Reveal key={p.no} delay={i * 50}>
                  <article className={`overflow-hidden rounded-[4px] border-2 bg-white transition ${open ? 'border-[#2563EB] shadow-[3px_4px_0_rgba(37,99,235,0.18)]' : 'border-[#191919]'}`}>
                    <button onClick={() => setOpenProject(open ? -1 : i)} aria-expanded={open} className="flex w-full items-center gap-4 px-5 py-5 text-left sm:px-6">
                      <span className={`mono hidden text-[13px] font-bold sm:block ${open ? 'text-[#2563EB]' : 'text-[#7A786E]'}`}>{p.no}</span>
                      <span className="min-w-0 flex-1"><span className="serif block truncate text-[17px] font-semibold tracking-tight text-[#191919] sm:text-[19px]">{p.title}</span><span className="mt-0.5 block truncate text-[13px] font-semibold text-[#4B4A45]">{p.sub}</span><span className="mt-1.5 inline-block rounded-full border border-[#2563EB]/50 bg-[#EAF0FE] px-2.5 py-0.5 text-[11px] font-bold text-[#1E40AF]">{p.status} · {p.statusNote}</span></span>
                      <span className="hidden rounded-full bg-[#F7F3EA] px-3 py-1.5 text-[11px] font-bold text-[#334155] lg:block">{p.stack}</span>
                      <span className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-full border ${open ? 'border-[#2563EB] bg-[#EAF0FE] text-[#2563EB]' : 'border-[#191919]/30 text-[#334155]'}`}><ChevronDown className={`chevron h-4 w-4 ${open ? 'open' : ''}`} /></span>
                    </button>
                    <div className={`acc-body ${open ? 'open' : ''}`}><div className="acc-inner"><div className="border-t border-[#191919]/15 px-5 pb-6 pt-4 sm:px-6">
                      <p className="max-w-3xl text-[14.5px] leading-relaxed text-[#4B4A45]">{p.desc}</p>
                      <div className="mt-4 flex flex-wrap gap-2">{p.tags.map(t => <span key={t} className="rounded-full bg-[#F7F3EA] px-3 py-1.5 text-[12px] font-bold text-[#334155]">{t}</span>)}</div>
                      <ul className="mt-4 grid gap-2 sm:grid-cols-3">{p.points.map(pt => <li key={pt} className="rounded-[4px] border border-[#191919]/15 px-3.5 py-3 text-[13px] font-semibold leading-snug text-[#334155]">{pt}</li>)}</ul>
                      <p className="mt-4 rounded-[4px] border border-dashed border-[#191919]/40 bg-[#F7F3EA] p-3.5 text-[13.5px] leading-relaxed text-[#334155]">{p.learned}</p>
                    </div></div></div>
                  </article>
                </Reveal>
              );
            })}
          </div>
        </section>

        {/* INTERESTS */}
        <section id="interests" className="border-y-2 border-[#191919] bg-[#EFEAE0] py-12 sm:py-16">
          <div className="mx-auto max-w-6xl px-4 sm:px-6">
            <Reveal><SectionHead no="04" eyebrow="INTERESTS" title="What I want to keep exploring." sub="Six directions — all connected by the same idea: make small things, learn out loud, and help the next beginner." /></Reveal>
            <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {INTERESTS.map((it, i) => <Reveal key={it.title} delay={i * 50}><div className="card-hover h-full rounded-[4px] border-2 border-[#191919] bg-[#FFFEFA] p-6"><span className="flex h-11 w-11 items-center justify-center rounded-[4px] border border-[#191919]/20 bg-[#EAF0FE] text-[#2563EB]"><it.icon className="h-5 w-5" /></span><h3 className="serif mt-4 text-[17px] font-semibold tracking-tight">{it.title}</h3><p className="mt-1.5 text-[14px] leading-relaxed text-[#4B4A45]">{it.text}</p></div></Reveal>)}
            </div>
            <Reveal><div className="mt-5 rounded-[4px] border-2 border-[#191919] bg-[#EAF0FE] p-5 sm:p-6"><p className="text-[15px] font-bold leading-relaxed text-[#1E40AF]">Strengthening foundations — open to hackathons, workshops, collabs, and internships.</p><p className="mt-1 text-[13.5px] leading-relaxed text-[#334155]">If you’re running something beginner-friendly, or building something small and useful, I’d love to hear about it.</p></div></Reveal>
          </div>
        </section>

        {/* CONTACT */}
        <section id="contact" className="mx-auto max-w-6xl px-4 py-12 sm:px-6 sm:py-16">
          <Reveal><SectionHead no="05" eyebrow="CONTACT" title="Let’s talk." sub="The fastest way to reach me is email. I’m in India, and happy to connect about internships, collabs, hackathons, or workshops." /></Reveal>
          <div className="mt-8 grid gap-5 lg:grid-cols-[1.1fr_.9fr]">
            <Reveal>
              <div className="rotate-[-0.3deg] rounded-[4px] border-2 border-[#191919] bg-[#191919] p-6 text-white sm:p-8">
                <p className="mono text-[11px] uppercase tracking-[0.16em] text-[#94A3B8]">Start a conversation</p>
                <h3 className="serif mt-3 text-[26px] font-semibold leading-tight">Open to internships<br />&amp; collabs.</h3>
                <p className="mt-3 max-w-md text-[14.5px] leading-relaxed text-[#CBD5E1]">Tell me what you’re building, what you’re learning, or what help you need. I’ll reply as soon as I can — usually between classes and debugging.</p>
                <a href="mailto:bhaveshsrivastava89@gmail.com" target="_blank" rel="noopener" className="mt-6 flex items-center justify-between gap-3 rounded-[4px] border-2 border-white bg-white p-4 text-[#191919] transition hover:bg-[#EAF0FE] active:scale-[0.99]"><span className="min-w-0"><span className="block text-[12px] font-bold uppercase tracking-[0.12em] text-[#7A786E]">Email</span><span className="mt-0.5 block truncate text-[14px] font-extrabold">bhaveshsrivastava89@gmail.com</span></span><ArrowUpRight className="h-5 w-5 shrink-0 text-[#2563EB]" /></a>
                <div className="mt-3 flex items-center gap-2 text-[13px] font-semibold text-[#CBD5E1]"><MapPin className="h-4 w-4 text-[#94A3B8]" />India · NIAT × Joy University, Tamil Nadu</div>
                <p className="hand mt-4 text-[14px] text-white/80">no fancy form here — email is easiest →</p>
              </div>
            </Reveal>
            <Reveal delay={80}>
              <div className="grid content-start gap-3">
                {[
                  { icon: Github, label: 'GitHub', value: 'github.com/bhaveshsrivastava89', href: 'https://github.com/bhaveshsrivastava89' },
                  { icon: Linkedin, label: 'LinkedIn', value: 'linkedin.com/in/bhaveshsrivastava89', href: 'https://linkedin.com/in/bhaveshsrivastava89' },
                  { icon: Phone, label: 'Phone', value: '+91 8551987112', href: 'tel:+918551987112' },
                  { icon: Mail, label: 'Email', value: 'bhaveshsrivastava89@gmail.com', href: 'mailto:bhaveshsrivastava89@gmail.com' },
                ].map(c => (
                  <a key={c.label} href={c.href} target="_blank" rel="noopener" className="card-hover flex items-center gap-4 rounded-[4px] border-2 border-[#191919] bg-white px-5 py-4">
                    <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-[4px] bg-[#F7F3EA] text-[#191919]"><c.icon className="h-5 w-5" /></span>
                    <span className="min-w-0 flex-1"><span className="block text-[12px] font-bold uppercase tracking-[0.12em] text-[#7A786E]">{c.label}</span><span className="block truncate text-[14.5px] font-extrabold text-[#191919]">{c.value}</span></span>
                    <ArrowUpRight className="h-4 w-4 shrink-0 text-[#7A786E]" />
                  </a>
                ))}
                <div className="flex items-start gap-2.5 rounded-[4px] border border-dashed border-[#191919]/40 bg-[#FFFEFA] p-4"><MessageSquare className="mt-0.5 h-4 w-4 shrink-0 text-[#2563EB]" /><p className="text-[13px] leading-relaxed text-[#4B4A45]">If I don’t reply straight away, I’m probably in class or building. Try again — I will get back to you.</p></div>
              </div>
            </Reveal>
          </div>
        </section>
      </main>

      <footer className="border-t-2 border-[#191919] bg-[#FFFEFA]">
        <div className="mx-auto flex max-w-6xl flex-col gap-3 px-4 py-7 sm:flex-row sm:items-center sm:justify-between sm:px-6">
          <p className="text-[13px] font-bold text-[#191919]">© 2026 Bhavesh Srivastava</p>
          <p className="text-[12.5px] font-semibold text-[#4B4A45]">Made by hand — HTML · CSS &amp; JS</p>
          <button onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} className="w-fit rounded-full border-2 border-[#191919] bg-white px-4 py-2 text-[12.5px] font-bold text-[#334155] transition hover:border-[#2563EB] hover:text-[#2563EB] active:scale-95">Back to top ↑</button>
        </div>
      </footer>
    </div>
  );
}

function SkillBar({ skill, index }: { skill: Skill; index: number }) {
  const { ref, inView } = useInView<HTMLDivElement>();
  const isBlue = ['Programming', 'AI & Creative'].includes(skill.group);
  return (
    <div ref={ref}>
      <div className="flex items-baseline justify-between gap-3"><p className="text-[14px] font-bold text-[#191919]">{skill.name} <span className="ml-1 text-[11px] font-bold uppercase tracking-wide text-[#7A786E]">· {skill.tag}</span></p><p className="mono text-[13px] font-bold text-[#191919]">{skill.level}%</p></div>
      <div className="mt-2 h-[9px] overflow-hidden rounded-full border border-[#191919]/20 bg-[#EFEAE0]"><div className="bar-fill h-full rounded-full" style={{ width: inView ? `${skill.level}%` : '0%', transitionDelay: `${index * 60}ms`, background: isBlue ? '#2563EB' : '#64748B' }} /></div>
      <p className="mt-1.5 text-[12px] font-semibold text-[#7A786E]">{skill.group} — <span className="hand text-[13px] text-[#2563EB]">{skill.note}</span></p>
    </div>
  );
}
